define(['jquery'], function(){

	var Menu = (function(){
		$('label.tree-toggler').click(function () {
			$(this).parent().children('ul.tree').toggle(300);
		});
		$("[id^=menu]").click(function(){
			$("#back_div").hide();
			var thisId = $(this).attr("id");
			$("[id^=content_]").hide();
			var showId = "#content_" + thisId;
			$(showId).show();
			$("[id^=menu]").removeClass("active");
			$(this).addClass("active");
		});

	})();
	return Menu;
});
