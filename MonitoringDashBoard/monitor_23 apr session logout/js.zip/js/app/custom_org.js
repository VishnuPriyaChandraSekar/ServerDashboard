$(document).ready(function(){

var table_list=document.getElementById('cpu_list');

// Automatic refresh of div's

setInterval(function(){$('#memory').load('memory.jspf').fadeIn("slow");}, 10000);
setInterval(function(){$('#connection').load('connectioninfo.jspf').fadeIn("slow");}, 10000);
setInterval(function(){$('#CPU').load('cpu.jspf').fadeIn("slow"); notification_alert();}, 10000);
setInterval(function(){$('#application').load('applicationinfo.jspf').fadeIn("slow");}, 10000);

// Menu tree - Production, Archives and Manage Servers

$('label.tree-toggler').click(function () {
	$(this).parent().children('ul.tree').toggle(300);
});


// Automatically hides the message after 10 seconds.

setTimeout(function() {
	$("#Message").fadeTo(1000, 0).slideUp(1000, function(){
	$(this).remove(); 
	});
}, 3000);


// Back button functionality in charts page.

$('#back_button').click(function(){
	$("#content_menu8").hide();
	$("#back_div").hide();
	$("#content_menu").show();
});	


// Displays only the menu that is active and hides/shrinks the other sub divisions.

$("[id^=menu]").click(function(){
	
	$("#back_div").hide();
	var thisId = $(this).attr("id");
	$("[id^=content_]").hide();
	var showId = "#content_" + thisId;
	$(showId).show();
	$("[id^=menu]").removeClass("active");
	$(this).addClass("active");
});

// Displays only the corresponding content div based on the click.
/*
$("[id^=environment]").click(function(){
	$("[id^=environment]").removeClass("active");
	$("[id^=cont_]").hide();
	var thisId1 = $(this).attr("id");
	var showId1 = "#cont_" + thisId1; 
	$(showId1).show();
});
*/
/*
$('#sidebar a').on('click', function () {
	$(this).closest('div').find('.collapse').collapse('hide');
	$(this).collapse('show');
});     

*/

	
// Alerts the user if the CPU utilization crosses 75%

$("#menu1").click(function(){
	var deep = document.getElementById("cpu_list").innerHTML;
	if( deep > 75 )
	{
		$("#myModal").show();
		$("#CPU").attr( "style" , "border:solid 2px #428BCA");
		$( "#myModal").dialog({
		modal: true
		});
	}
});

// Function to display the charts when the server on the homepage is selected.

$("[id^=menu8]").click(function(){
	var ClickId = $(this).attr("id");
	$("#content_menu").hide(); 
        $("#back_div").show(); 
	$("#content_menu8").show();
	display_charts(ClickId);
});

// Date picker for webserver logs  

$('#datetimepicker2').datepicker({
	language: 'en',
	pick12HourFormat: false,
	format:"yyyy-mm-dd"
});

// Date picker for appserver logs 

$('#datetimepicker').datepicker({
	language: 'en',
	pick12HourFormat: false,
	format:"yyyy-mm-dd"
});

// Functionality for loading symbol to appear while starting or stopping the servers.

$("[id^=button]").on('click', function() {
	var thisbutton = $(this).attr("id");
	var image;
        if(thisbutton.match("^button_server"))
		image="#gif_button_server";
	else
		image= "#gif_"+thisbutton;
                $(image).show();
});

// Functionality for alerts
	
var notifications = new $.ttwNotificationMenu({
	notificationList:{
            anchor:'item',
            offset:'0 15'
        }
	});

    notifications.initMenu({
       tasks:'#tasks',
    });


// Notification conditions and respective alerts


function notification_alert()
{
	for (var i = 1, n = table_list.rows.length; i < n; i++)
	{	
		var cpu_name=table_list.rows[i].cells[1].innerHTML;
		var cpu_util=table_list.rows[i].cells[5].innerHTML.replace('%','').trim();		
		if(cpu_util>75)
		{
			var noti_options = {
	                category:'tasks',
	        	message: 'CPU Utilization is high in' +cpu_name
	       		};
			notifications.createNotification(noti_options);			
		}
	}
}


// Call for alerts function
	
notification_alert();

});


