
define(['jquery'], function($){

var Refresh = (function(){
		setInterval(function(){$('#CPU').load('cpu.jspf').fadeIn("slow");require(["app/alerts"], function (alerts) {
				alerts.notificationAlert();
			});}, 30000);
		setInterval(function(){$('#memory').load('memory.jspf').fadeIn("slow");}, 30000);
		setInterval(function(){$('#connection').load('connectioninfo.jspf').fadeIn("slow");}, 30000);
		
		setInterval(function(){$('#application').load('applicationinfo.jspf').fadeIn("slow");}, 30000);
	//	test.notificationAlert();
		if($('#Message').is(':visible')){
			setTimeout(function() {
				$("#Message").fadeTo(1000, 0).slideUp(1000, function(){
				$(this).remove(); 
			});
			}, 3000);
		}		

	})();
	
	return Refresh;

});


