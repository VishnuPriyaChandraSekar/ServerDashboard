define(["jquery","ttw-notification-menu"], function($,ttwNotificationMenu) {

var alerts = function () {
    return {
      notificationAlert: function () {
		var table_list=document.getElementById('cpu_list');
		var mem_list=document.getElementById('memory-info-table');

		var notifications = new $.ttwNotificationMenu({
		notificationList:{
        	    anchor:'item',
	           offset:'0 15'
       		 }
		});
		notifications.initMenu({
		tasks:'#tasks',
		});
	
	for (var i = 1, n = table_list.rows.length; i < n; i++)	
	{
		var cpu_name=table_list.rows[i].cells[1].innerHTML;
		var cpu_util=table_list.rows[i].cells[5].innerHTML.replace('%','').trim();		
		if(cpu_util>75){
			var noti_options = {
	        	        category:'tasks',
		        	message: 'CPU Utilization is high in' +cpu_name
	       		};
			notifications.createNotification(noti_options);			
		}
	}

	
	for (var j = 1, len = mem_list.rows.length; j < len; j++)	
	{
		var server_name=mem_list.rows[j].cells[1].innerHTML;
		var mem_used=mem_list.rows[j].cells[4].innerHTML.replace('MB','').trim();
		var mem_tot=mem_list.rows[j].cells[2].innerHTML.replace('MB','').trim();		
		var used= (mem_used/mem_tot)*100;
		if(used>75)
		{
			var noti_options1 = {
		                category:'tasks',
			       	message: 'RAM usage is high in' + server_name
		       	};
			notifications.createNotification(noti_options1);			
		}
	}

      }
    }

  }
  return new alerts;

});
