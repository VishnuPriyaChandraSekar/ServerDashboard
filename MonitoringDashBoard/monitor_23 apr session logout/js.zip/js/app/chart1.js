define(['jquery','jsapi'],function ( $,jsapi) {

var Charts = (function(){
	var ClickId;
	var web_table = document.getElementById('backup_table');
	var app_table= document.getElementById('application_backup_table');
	var mem_table=document.getElementById('memory-info-table');
	
	var free_mem = mem_table.rows[1].cells[3].innerHTML.trim();
	free_mem= parseInt(free_mem.slice(0,6));
	
	var Used_mem=mem_table.rows[1].cells[4].innerHTML.trim();
	Used_mem= parseInt(Used_mem.slice(0,6));
	
	var swap_mem = mem_table.rows[1].cells[7].innerHTML.trim();
	swap_mem= parseInt(swap_mem);  

	function lineChart(server_name,server_type) 
	{
		var cpu_line =new google.visualization.DataTable();
		cpu_line.addColumn('string', 'Datetime');
		cpu_line.addColumn('number', 'Usage');

		if(!server_type.localeCompare("web"))
		{
			for (var i = 1, n = web_table.rows.length; i < n; i++)
			{	
				var tab_server=web_table.rows[i].cells[1].innerHTML.trim();
		         	if(!server_name.localeCompare(tab_server))
				{	
					cpu_line.addRows([[web_table.rows[i].cells[0].innerHTML,parseInt(web_table.rows[i].cells[6].innerHTML)]]);
				}
		        }	
		}

		else if(!server_type.localeCompare("app"))
		{
			for (var i = 1, n = app_table.rows.length; i < n; i++)
			{	
				var tab_server=app_table.rows[i].cells[1].innerHTML.trim();
		         	if(!server_name.localeCompare(tab_server))
				{	
					cpu_line.addRows([[app_table.rows[i].cells[0].innerHTML,parseInt(app_table.rows[i].cells[6].innerHTML)]]);
				}
		        }
		}	
     
	        var options_line = { title: 'CPU Utilization', 'width':450, 'height':300,titleTextStyle :{ color: '#428BCA', fontSize: 16, bold: false },is3D: true, height:300, legend: 			{position: 'right', alignment: 'center'}, vAxis:{title:'CPU Utilization',format: '#\'%\'',minValue:'0',maxValue:'100'}, hAxis:{title:' Timestamp '} };

		var chart_CPU = new google.visualization.SteppedAreaChart(document.getElementById('cpuChart'));
        	chart_CPU.draw(cpu_line, options_line);     
	}

// Bar Chart for hits and misses Starts
 
	function barChart(server_name)
	{
		var hitsline =new google.visualization.DataTable();
		hitsline.addColumn('string', 'Builds');
	        hitsline.addColumn('number', 'Hits');
		hitsline.addColumn('number', '404 errors');

		for (var r = 1, n = web_table.rows.length; r < n; r++)
		{
			var tab_server1=web_table.rows[r].cells[1].innerHTML.trim();
         		if(!server_name.localeCompare(tab_server1))
			{	
        	  		hitsline.addRows([[web_table.rows[r].cells[0].innerHTML,parseInt(web_table.rows[r].cells[11].innerHTML),parseInt(web_table.rows[r].cells[12].innerHTML)]]);
			}
		}

		var options_hits = { title: 'Hits Vs Page not found Errors', titleTextStyle :{ color: '#428BCA', fontSize: 16, bold: false, position:'center' },is3D:true,'width':650, 			'height':300, legend: {position: 'right', alignment: 'center'}, orientation:'horizontal',vAxis:{title:'No.of hits and errors', minValue:'0'}, hAxis:{title:' Timestamp'} };

		var line = new google.visualization.BarChart(document.getElementById('linechart'));
		line.draw(hitsline, options_hits);
	}
// Bar Chart for hits and misses ends


// Pie Chart for CPU Utilization Starts

	function drawChart()
	{
		var data = new google.visualization.DataTable();
		data.addColumn('string', 'Memory');
		data.addColumn('number', 'KB');
		data.addRows([ ['Free Memory', free_mem], ['Used Memory', Used_mem ], ['Swap Memory', swap_mem ] ]);

		var options = {'title':'RAM Utilization',is3D: true,'width':500, 'height':350, titleTextStyle :{ color: '#428BCA', fontSize: 16, bold: false } };

		var chart = new google.visualization.PieChart(document.getElementById('piechart'));
		chart.draw(data, options);
	}

// Pie Chart for CPU Utilization Ends


// Combo Chart for app server - connection time, lookup time and transfer time starts

	function combo_chart(server_name) 
	{
		var connection =new google.visualization.DataTable();
		connection.addColumn('string', 'Timestamp');
	        connection.addColumn('number', 'Lookup time');
		connection.addColumn('number', 'Connection time');
		connection.addColumn('number', 'Transfer time');

		for (var r = 1, n = app_table.rows.length; r < n; r++)
		{
			var tab_server2=app_table.rows[r].cells[1].innerHTML.trim();
         		if(!server_name.localeCompare(tab_server2))
			{	
				connection.addRows([[app_table.rows[r].cells[0].innerHTML,parseFloat(app_table.rows[r].cells[9].innerHTML),parseFloat(app_table.rows[r].cells[10].innerHTML),parseFloat(app_table.rows[r].cells[11].innerHTML)]]);
			}
		}
	
		var options3 = {
			title : 'Connection Information',
			vAxis: {title: " Seconds",minValue:'0', format: '0.000',gridlines: { 	count: 10 }  },
			hAxis: {title: " Timestamp "},
			seriesType: "bars",
			series: {3: {type: "line"}},
			titleTextStyle :{ color: '#428BCA', fontSize: 16, bold: false },
			is3D: true,
			'width':650,'height':300,
			legend: {position: 'right', alignment: 'center'}	  
	          };

        	var chart = new google.visualization.ComboChart(document.getElementById('linechart'));
	        chart.draw(connection, options3);
	}



	function display_chart()
	{
		var server_type=ClickId.substring(7,10);
		var server_name=ClickId.substring(11,ClickId.length);
		$("#content_menu").hide();
		$("#back_div").show();
		$("#content_menu8").show();
		
		lineChart(server_name,server_type);
		if(!server_type.localeCompare("web"))
		{
			barChart(server_name); 
		}
		else if(!server_type.localeCompare("app"))
		{
			combo_chart(server_name);
		}          
		drawChart();
	}
	
	$("[id^=server]").click(function()
	{
		ClickId = $(this).attr("id");
		google.load("visualization", "1", {'packages':['corechart'],"callback" : display_chart});
	});
   })();

return Charts;  
});





