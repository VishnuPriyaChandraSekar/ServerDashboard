define(['jquery','bootstrap-datepicker'], function($,dt){

	var DateTime = (function(){
		$('#datetimepicker2').datepicker({
			language: 'en',
			pick12HourFormat: false,
			format:"yyyy-mm-dd"
		});	

		// Date picker for appserver logs 
		$('#datetimepicker').datepicker({
			language: 'en',
			pick12HourFormat: false,
			format:"yyyy-mm-dd"
		});

	})();
	return DateTime;
});

