$("#menu1").click(function(){
	var deep = document.getElementById("cpu_list").innerHTML;
	if( deep > 75 )
	{
		$("#myModal").show();
		$("#CPU").attr( "style" , "border:solid 2px #428BCA");
		$( "#myModal").dialog({
		modal: true
		});
	}
});
