// Back button functionality in charts page.
define(['jquery'], function($){

var BackBtn = (function(){

		if($("#content_menu8").is(':visible')){
			$('#back_button').show();
		}else{
			$('#back_button').hide();
		}


		$('#back_button').click(function(){
			$("#content_menu8").hide();
			$("#back_div").hide();
			$("#content_menu").show();
		});	
	})();
return BackBtn;
});
