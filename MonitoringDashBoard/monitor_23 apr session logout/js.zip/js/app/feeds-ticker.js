define(['jquery','jquery.tegnewsticker-v1'], function($,tegnewsticker){
	
	var NewsTicker = (function(){
		$.tegnewsticker('.feeds');
		$.tegnewsticker('.dataload');
		$.tegnewsticker('.updates');
		$.tegnewsticker('.jobs');	
	})();

	return NewsTicker;
});
