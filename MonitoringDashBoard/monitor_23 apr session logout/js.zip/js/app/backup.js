define(["jquery","table_metadata","table_sorter","table_cloth"], function($,tableMeta, tableSorter,tableCloth){
var backup = (function(){
	$("[id$=backup_table]").tablecloth({
        sortable: true,
        });
})();
return backup;
});


