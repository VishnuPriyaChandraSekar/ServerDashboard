// Functionality for loading symbol to appear while starting or stopping the servers.

define(['jquery'], function($){
	var BusyLoader = (function(){
		$("[id^=button]").on('click', function() {
		var thisbutton = $(this).attr("id");
		var image;
        	if(thisbutton.match("^button_server"))
			image="#gif_button_server";
		else
			image= "#gif_"+thisbutton;
                	$(image).show();
		});	
		
	})();

	return BusyLoader;
});

