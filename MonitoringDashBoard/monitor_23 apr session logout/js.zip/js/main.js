require.config({
    "baseUrl" : "js",
    "paths" : {
        "jquery" : "../js/lib/jquery",
	"js" : "../js",
	"app" : "../js/app",
	"lib" : "../js/lib",
	"ttw-notification-menu": "../js/lib/ttw-notification-menu",
	"jquery.tegnewsticker-v1" : "../js/lib/jquery.tegnewsticker-v1",
	"bootstrap-datepicker" : "../js/lib/bootstrap-datepicker",
	"notify" : "../js/app/notify",
	"alerts" : "../js/app/alerts",
	"jsapi" : "../js/lib/jsapi",
	"table_metadata" : "../js/lib/jquery.metadata",
	"table_sorter" : "../js/lib/jquery.tablesorter.min",
	"table_cloth" : "../js/lib/jquery.tablecloth"
    },
    waitSeconds: 0
});


define(['jquery'], function($) {
	var Main = {

		init : function() {

			require(["lib/bootstrap.min"]);
			require(["lib/bootstrap-dropdown"]);
			require(["app/notify"]);
			require(["app/refresh"]);
			require(["app/chart1"]);
			
			if ($('#back_button').length > 0)
				require(["app/back_button"]);

			if( $('.feeds').length > 0 )
				require(["app/feeds-ticker"]);

			if( $("[id^=button]").length > 0)
				require(["app/loading"]);
	
			if( $("[id^=menu]").length > 0)
				require(["app/menu"]);

			if( $("[id^=datetimepicker]").length > 0)
				require(["app/picker"]);
		
			if( $("[id$=backup_table]").length > 0)
				require(["app/backup"]);	

		}
	};
    window.Main = Main;
    Main.init();	
});
