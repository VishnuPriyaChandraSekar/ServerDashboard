import java.io.*; 
import java.lang.*; 
import java.util.*; 
import javax.servlet.*;  
import javax.servlet.http.*; 
import com.*;

public class MyStopServer extends HttpServlet {  
   
  public void doGet(HttpServletRequest request, HttpServletResponse response)
                               throws ServletException, IOException {


	Server ser = new Server();
	ser.server_name=request.getParameter("server_list");
	callScript(ser);
	int exit1=ser.result;

	if(exit1 == 0)
	{
 		response.setContentType("text/html");
		request.setAttribute("flag2","Success");
	}
	else if (exit1 == 1)
	{
		response.setContentType("text/html");
		request.setAttribute("flag2","Failure");
	}
        else 
          {
		response.setContentType("text/html");
		request.setAttribute("flag2","Already");
	}

	request.setAttribute("console_message",ser.message);
	request.setAttribute("console_error_message",ser.emessage);
        request.setAttribute("stop_server_name",ser.server_name);

	RequestDispatcher rd = request.getRequestDispatcher("/home.jsp");
	rd.forward(request, response);	

   }




  public Server callScript(Server server){  

String stop_server_cmd;
String stop_server_check;
String user;
String msg;
String emsg;

if(server.server_name.equals("httpd"))
{       user="root";
	stop_server_cmd="cd /opt/IBMIHS/bin && ./apachectl -f /opt/IBM/WebSphere/CommerceServer70/instances/demo/httpconf/httpd.conf -k stop";
	stop_server_check="ps -ef | grep -v grep | grep httpd";
}
else
{	user="wcsadmin";
	stop_server_cmd="cd /opt/IBM/WebSphere/AppServer/profiles/demo/bin && ./stopServer.sh server1";
	stop_server_check="ps -efwww | grep -v grep | grep server1";
}

   
try{
	Runtime rt = Runtime.getRuntime();
	String[] cmd = { "su",user,"-c", stop_server_check };
	Process proc = rt.exec(cmd);
	BufferedReader is = new BufferedReader(new InputStreamReader(proc.getInputStream()));
	String line;
	String line1=null; 
	System.out.println("-------wcstest.com Status Stop Starts--------");
	System.out.println("************Previous Status*****************");
	while ((line = is.readLine()) != null) {
		line1+=line;
        	System.out.println(line);
	}
	 System.out.println("************Previous Status Ends***********");    
    if (line1 == null)
    {
	
	server.result=2;
	System.out.println("Server Already Stopped");
    }  
   
    else
    {
	Runtime rt1=Runtime.getRuntime();
	String[] cmd1 = {"su",user, "-c",stop_server_cmd};
	Process proc1 = rt1.exec(cmd1);
	int status = proc1.waitFor();
	 System.out.println("************Current Status*****************");
	BufferedReader inOut = new BufferedReader(new InputStreamReader(proc1.getInputStream()));
    	BufferedReader inErr = new BufferedReader(new InputStreamReader (proc1.getErrorStream()));
	
	while ((msg = inOut.readLine()) != null)
	{
	      server.message+="\n"+msg +"\n" ;
  	}
	System.out.println("If any error exist ..Then error message appears below.");
	while ((emsg = inErr.readLine()) != null)
	{
	      	server.emessage+="\n"+emsg + "\n" ;
	}

	 System.out.println("************Current Status*****************");
	if(status==0)
        {
	   System.out.println("Server Stopped successfully");
	   server.result=0;
	}
       else 
	{
	   System.out.println("Error occurred while stopping the server");
           server.result=1;
	}
    }
 }
catch (Exception e) {
    e.printStackTrace();
    }
System.out.println("------------Wcstest.com Server Stop Status ends-----------");
return server;
} 
}
