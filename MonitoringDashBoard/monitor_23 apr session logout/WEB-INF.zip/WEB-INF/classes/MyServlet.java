import java.io.*; 
import java.lang.*; 
import java.util.*; 
import javax.servlet.*;  
import javax.servlet.http.*; 
import com.*;

public class MyServlet extends HttpServlet {  
   
  public void doGet(HttpServletRequest request, HttpServletResponse response)
                               throws ServletException, IOException {
Server ser = new Server();
ser.server_name=request.getParameter("server_list");
 callScript(ser);
int exit1=ser.result;
	if(exit1 == 0)
	{
 		response.setContentType("text/html");
		request.setAttribute("flag1","Success");
     	}
	else if (exit1 == 1)
	{
		response.setContentType("text/html");
		request.setAttribute("flag1","Failure");
	}
        else 
          {
		response.setContentType("text/html");
		request.setAttribute("flag1","Already");
	}

	request.setAttribute("console_message",ser.message);
	request.setAttribute("console_error_message",ser.emessage);
        request.setAttribute("server_name",ser.server_name);
	RequestDispatcher rd = request.getRequestDispatcher("/home.jsp");
	rd.forward(request, response);	

   }


  public Server callScript(Server server){  
  
String server_cmd;
String server_check;
String user;
String msg;
String emsg;
   
 if(server.server_name.equals("httpd"))
		{
               user="root";
               server_cmd="cd /opt/IBMIHS/bin && ./apachectl -f /opt/IBM/WebSphere/CommerceServer70/instances/demo/httpconf/httpd.conf -k start";
               server_check="ps -ef | grep -v grep | grep httpd";
		}
 else
	       {
                user="wcsadmin";
		server_cmd="cd /opt/IBM/WebSphere/AppServer/profiles/demo/bin && ./startServer.sh server1";
		server_check="ps -efwww | grep -v grep | grep server1";
               }
try{
       
	Runtime rt = Runtime.getRuntime();
	String[] cmd = { "su",user,"-c", server_check};
	Process proc = rt.exec(cmd);
	BufferedReader is = new BufferedReader(new InputStreamReader(proc.getInputStream()));
	String line;
	String line1=null; 
	System.out.println("-------wcstest.com Status Starts--------");
	System.out.println("************Previous Status*****************");

	while ((line = is.readLine()) != null) {
		line1+=line;
        	System.out.println(line);
	}
	    System.out.println("************Previous Status Ends***********");
	
	if (line1 == null)
	{
	Runtime rt1=Runtime.getRuntime();
	String[] cmd1 = {"su",user ,"-c",server_cmd};
	Process proc1 = rt1.exec(cmd1);
	int status = proc1.waitFor();

	BufferedReader inOut = new BufferedReader(new InputStreamReader(proc1.getInputStream()));
    	BufferedReader inErr = new BufferedReader(new InputStreamReader (proc1.getErrorStream()));
        System.out.println("************Current Status*****************");
	while ((msg = inOut.readLine()) != null)
	{
	      server.message+="\n" +msg +"\n" ;
  	}
	System.out.println("If any error exist ..Then error message appears below.");
	while ((emsg = inErr.readLine()) != null)
	{
	      	server.emessage+="\n"+ emsg + "\n" ;
	}
        System.out.println("************Current Status*****************");
	if(status==0)
       	{
           server.result=0;
	   System.out.println(server.server_name+"  Server is Started");
	}
       else 
	{
           server.result=1;
	   System.out.println(server.server_name+"  Error occurred while starting server");
	}
    }  
   
    else
    {
	server.result=2;
	System.out.println(server.server_name+" Server is already started");
    }
 }
catch (Exception e) {
    e.printStackTrace();
    }
System.out.println("------------Wcstest.com Server Status ends-----------");
return server;
} 
}
