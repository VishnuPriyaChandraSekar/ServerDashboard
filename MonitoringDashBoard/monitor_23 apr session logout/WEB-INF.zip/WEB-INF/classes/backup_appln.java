import java.io.*; 
import java.lang.*; 
import java.util.*; 
import javax.servlet.*;  
import javax.servlet.http.*;
public class backup_appln extends HttpServlet {  
   
public void doGet(HttpServletRequest request, HttpServletResponse response)
                               throws ServletException, IOException {
		  String filename =null;
			String[] file;
		try { 

			if(request.getParameter("jspfpicker") != "")
			{	
			String match_name="backup_"+request.getParameter("jspfpicker");	
		
			File dir = new File("/opt/apache-tomcat-7.0.39/webapps/monitor/backup_logs/web_server");
			if (!dir.exists()) {
				dir.createNewFile();
			}
			if(dir.isDirectory ())
 			{
				file=dir.list();
				for(int i=0;i<file.length;i++)
				{
                                	if(file[i].startsWith(match_name))               
                                        { 
                                                filename="backup_logs/web_server/"+file[i];
						System.out.println("Success found the file");
         					System.out.println("Matched file    :"+filename);
						break;
                               		}
					filename="notfound";	
				}
			}
 			}
			else
			{
				filename="empty";	
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

		request.setAttribute("backup",filename);
		RequestDispatcher rd = request.getRequestDispatcher("/home.jsp");
		rd.forward(request, response);	

}
}
