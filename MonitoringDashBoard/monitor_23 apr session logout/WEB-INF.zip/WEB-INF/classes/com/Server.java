package com;
public class Server
{
public String server_name;
public int result=1;
public String message=null;
public String emessage=null;

}
