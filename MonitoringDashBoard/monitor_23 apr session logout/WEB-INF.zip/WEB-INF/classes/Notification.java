import java.io.*; 
import java.lang.*; 
import java.util.*; 
import javax.servlet.*;  
import javax.servlet.http.*;
public class Notification extends HttpServlet {  
   
public void doPost(HttpServletRequest request, HttpServletResponse response)
                               throws ServletException, IOException {
		
		try { 
			String content = "<blockquote>"+request.getParameter("new_message") + "</blockquote>"+ "\n";
			String category = request.getParameter("subject");		
			String file_name="/opt/apache-tomcat-7.0.39/webapps/monitor/";		
	
			System.out.println(category);			
			System.out.println(content);			
			
			switch(category)
			{
				case "feeds": 	file_name=file_name+"feeds.jspf";
						break;
				case "dataload":
						file_name=file_name+"dataload.jspf";
						break;
				case "updates":
						file_name=file_name+"updates.jspf";
						break;
				case "jobs":	
						file_name=file_name+"jobs.jspf";
						break;
				
			}
			

			File file = new File(file_name);

			// if file doesnt exists, then create it
			if (!file.exists()) {
				file.createNewFile();
			}
 
			LineNumberReader  lnr = new LineNumberReader(new FileReader(file));
			lnr.skip(Long.MAX_VALUE);
		
			FileWriter fw = null;
			BufferedWriter bw = null;
			
			// Deletes the content if the number of lines crosses 10
			if(lnr.getLineNumber()<10)
			{
				fw =new FileWriter(file.getAbsoluteFile(),true);
				bw= new BufferedWriter(fw);
				bw.write(content);
			}
			else
			{
				fw =new FileWriter(file.getAbsoluteFile(),false);
				bw= new BufferedWriter(fw);
			}
			bw.close();
			
			System.out.println("File Write Done");
 
		} catch (IOException e) {
			e.printStackTrace();
		}

		request.setAttribute("notified","posted");
		RequestDispatcher rd = request.getRequestDispatcher("/home.jsp");
		rd.forward(request, response);	

}
}
