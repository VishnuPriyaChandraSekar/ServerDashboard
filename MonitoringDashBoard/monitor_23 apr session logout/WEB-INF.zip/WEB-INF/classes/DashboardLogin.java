import java.io.*; 
import java.lang.*; 
import java.util.*; 
import javax.servlet.*;  
import javax.servlet.http.*; 
import java.util.Scanner;

public class DashboardLogin extends HttpServlet {  

protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
{
	HttpSession session = request.getSession(true); 
	String username=request.getParameter("username");
	String password=request.getParameter("password");
	int check=check_user(username,password);

	if (check == 1)
	{
		request.setAttribute("login_check","success");
		session.setAttribute("user", username);
		response.sendRedirect("home.jsp");
	}
	else
	{
		request.setAttribute("login_check","fail");
		RequestDispatcher rd = request.getRequestDispatcher("/index.jsp");
		rd.forward(request, response);
	}
}


public int check_user(String username, String password)throws IOException 
{
	int flag=0;
	try 
	{
        	FileReader file =new FileReader("/opt/apache-tomcat-7.0.39/webapps/monitor/logindetails.txt");
		Scanner read = new Scanner (file);
		read.useDelimiter("[,\n]");
		String db_user, db_pwd;
		while(read.hasNext() != false)
		{
			db_user=read.next();
			db_pwd=read.next();
        	        if (db_user.equals(username) && db_pwd.equals(password))
                	{
				flag=1;
                       		System.out.println("Successfully logged in");
				break;
                        }
		}
		read.close();
	}
	catch (IOException e)
	{
		e.printStackTrace();
	}
return flag;
}


protected void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException 
{
	HttpSession session_out = request.getSession(false);
	if(session_out != null)
		session_out.invalidate();
	RequestDispatcher rd = request.getRequestDispatcher("/index.jsp");
	rd.forward(request, response);
}

}
